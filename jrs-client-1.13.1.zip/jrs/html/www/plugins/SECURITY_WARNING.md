----
# PLUGIN SECURITY WARNING #

----
Plugins are not sandboxed or restricted in any way and have full access
to your client system including your passphrase.

Make sure to only run plugins downloaded from trusted sources, otherwise
you can compromise your company's network! 

Logging into the client without remembering the passphrase won't make
the process more secure.
